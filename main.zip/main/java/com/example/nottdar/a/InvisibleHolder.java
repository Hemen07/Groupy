package com.example.nottdar.a;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InvisibleHolder extends RecyclerView.ViewHolder {
    private static final String TAG = "InvisibleHolder" + " : ";
    @BindView(R.id.invisible_row_parent_rl)
    RelativeLayout mRelativeLayout;



    public InvisibleHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        Log.d(TAG, "InvisibleHolder(): ");

    }

    public void bind(UserModel mUserModel) {

    }
}