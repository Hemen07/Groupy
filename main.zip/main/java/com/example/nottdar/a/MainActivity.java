package com.example.nottdar.a;

import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements AdapterCallbacks {
    private static final String TAG = "MainActivity" + " : ";
    @BindView(R.id.rv)
    RecyclerView recyclerView;

    private MyAdapter myAdapter;
    private List<UserModel> mUserModelList = new ArrayList<>();
    private LinearLayoutManager layoutManager;

    private int ORIENTATION;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        Log.e(TAG, "onCreate(): ");

        setUpRecycler();
        addItems();
        setAdapter();

        recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                Log.v(TAG, "onScrollStateChanged(): " + newState);
            }

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                Log.v(TAG, "onScrolled(): " + dx + " " + dy);
                //infinite bullshit
               /* int firstItemVisible = layoutManager.findFirstVisibleItemPosition();
                if (firstItemVisible != 0 && firstItemVisible % mUserModelList.size() == 0) {
                    recyclerView.getLayoutManager().scrollToPosition(0);
                }*/
                layoutManager.scrollToPosition(Integer.MAX_VALUE / 2);



                /*if (dx > 0) {
                    ORIENTATION = LinearLayout.HORIZONTAL;
                }
                if (dx < 0) {
                    ORIENTATION = LinearLayout.HORIZONTAL;
                }
                layoutManager.setOrientation(ORIENTATION);
                recyclerView.setLayoutManager(layoutManager);
                recyclerView.getAdapter().notifyDataSetChanged();*/


            }
        });


    }

    @Override
    public void onLongClick(int position, View view) {

    }

    private void setUpRecycler() {
        Log.d(TAG, "setUpRecycler()");
        myAdapter = new MyAdapter(mUserModelList, this, this);
        layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(myAdapter);
    }

    private void addItems() {
        Log.d(TAG, "addItems(): ");
        UserModel userModel1 = new UserModel("1", "AA", false);
        UserModel userModel2 = new UserModel("2", "BB", false);
        UserModel userModel3 = new UserModel("3", "CC", false);
        UserModel userModel4 = new UserModel("4", "DD", true);
        mUserModelList.add(userModel1);
        mUserModelList.add(userModel2);
        mUserModelList.add(userModel3);
        mUserModelList.add(userModel4);
    }

    private void setAdapter() {
        Log.d(TAG, "setAdapter(): ");
        myAdapter = new MyAdapter(mUserModelList, this, this);
        recyclerView.setAdapter(myAdapter);
        myAdapter.notifyDataSetChanged();

    }

}
