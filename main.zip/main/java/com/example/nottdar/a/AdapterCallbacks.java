package com.example.nottdar.a;

import android.view.View;

public interface AdapterCallbacks {
    public void onLongClick(int position, View view);

}
