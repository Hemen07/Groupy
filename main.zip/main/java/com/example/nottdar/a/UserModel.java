package com.example.nottdar.a;

public class UserModel {

    private String mChannelName;
    private String mChannelDesc;
    private boolean mIsLast;

    public UserModel(String mChannelName, String mChannelDesc, boolean mIsLast) {
        this.mChannelName = mChannelName;
        this.mChannelDesc = mChannelDesc;
        this.mIsLast = mIsLast;
    }

    public String getmChannelName() {
        return mChannelName;
    }

    public void setmChannelName(String mChannelName) {
        this.mChannelName = mChannelName;
    }

    public String getmChannelDesc() {
        return mChannelDesc;
    }

    public void setmChannelDesc(String mChannelDesc) {
        this.mChannelDesc = mChannelDesc;
    }

    public boolean ismIsLast() {
        return mIsLast;
    }

    public void setmIsLast(boolean mIsLast) {
        this.mIsLast = mIsLast;
    }
}
