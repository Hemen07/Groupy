package com.example.nottdar.a;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class NormalHolder extends RecyclerView.ViewHolder {
    private static final String TAG = "NormalHolder" + " : ";
    @BindView(R.id.normal_ch_name_tv)
    TextView mChannelName;
    @BindView(R.id.normal_ch_shortdesc_tv)
    TextView mChannelDesc;


    public NormalHolder(View itemView) {
        super(itemView);
        ButterKnife.bind(this, itemView);
        Log.d(TAG, "NormalHolder(): ");

    }

    public void bind(UserModel mUserModel) {
        mChannelName.setText(mUserModel.getmChannelName());
        mChannelDesc.setText(mUserModel.getmChannelDesc());


    }
}