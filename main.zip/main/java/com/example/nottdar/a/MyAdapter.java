package com.example.nottdar.a;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;

import java.util.ArrayList;
import java.util.List;


public class MyAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final static String TAG = MyAdapter.class.getSimpleName();
    private final static boolean LOG_DEBUG = true;

    private static final int VIEW_TYPE_NORMAL = 1;
    private static final int VIEW_TYPE_INVISIBLE = 2;
    private int selectedItem = -1;


    private List<UserModel> userModelList;
    private Context mContext;
    private AdapterCallbacks mAdapterCallbacks;
    private View v;


    public MyAdapter(List<UserModel> userModelList, Context mContext, AdapterCallbacks mAdapterCallbacks) {
        Log.w(TAG, "MyAdapter(): ");
        this.userModelList = userModelList;
        this.mContext = mContext;
        this.mAdapterCallbacks = mAdapterCallbacks;
    }


    @Override
    public int getItemViewType(int position) {
        UserModel mUserModel = userModelList.get(position);
        boolean isLast = mUserModel.ismIsLast();
        //  Log.e(TAG, "getItemViewType(): " + isLast);

        if (!isLast) {
            // if (LOG_DEBUG) System.out.println("       VIEW_TYPE_NORMAL  ");
            return VIEW_TYPE_NORMAL;
        } else {
            // if (LOG_DEBUG) System.out.println("       VIEW_TYPE_INVISIBLE  ");
            return VIEW_TYPE_INVISIBLE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        if (viewType == VIEW_TYPE_NORMAL) {
            //  if (LOG_DEBUG) System.out.println("       onCreate()  -- VIEW_TYPE_NORMAL  ");
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.normal_row, parent, false);
            return new NormalHolder(v);
        } else if (viewType == VIEW_TYPE_INVISIBLE) {
            // if (LOG_DEBUG) System.out.println("       onCreate()  -- VIEW_TYPE_INVISIBLE  ");
            v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.invisble_row, parent, false);
            return new InvisibleHolder(v);
        }

        return null;

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder myViewHolder, int position) {
        position = position % userModelList.size();
        //
        if (mContext != null) {
            UserModel mUserModel = userModelList.get(position % userModelList.size());
            if (mUserModel != null) {
                switch (myViewHolder.getItemViewType()) {
                    case VIEW_TYPE_NORMAL:
                        if (LOG_DEBUG)
                            //   System.out.println("       onBind()  -- VIEW_TYPE_NORMAL  ");
                            ((NormalHolder) myViewHolder).bind(mUserModel);
                        if (position == selectedItem) {
                            myViewHolder.itemView.setAnimation(AnimationUtils.loadAnimation(mContext, R.anim.zoom_in));
                         /*   holder.tvDate.setTextColor(Color.parseColor("#094673"));
                            holder.tvDate.setTextSize(35);
                            holder.imgSmall.setBackgroundResource(R.color.textviewbold);*/

                        } else {
                           /* holder.tvDate.setTextColor(Color.GRAY);
                            holder.tvDate.setTextSize(35);
                            holder.imgSmall.setBackgroundResource(R.color.gray);*/
                        }

                        break;
                    case VIEW_TYPE_INVISIBLE:
                        if (LOG_DEBUG)
                            // System.out.println("       onBind()  -- VIEW_TYPE_INVISIBLE  ");
                            ((InvisibleHolder) myViewHolder).bind(mUserModel);
                        break;
                    default:
                }
            }
        }

    }

    @Override
    public int getItemCount() {
        return Integer.MAX_VALUE;
       // return userModelList == null ? 0 : userModelList.size() * 2;

        //  return (userModelList != null ? userModelList.size() : 0);
    }


}
